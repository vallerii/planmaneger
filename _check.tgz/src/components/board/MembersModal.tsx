"use client";

import { useI18n } from "@/i18n/client";
import { useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { ROLE_LABEL, type Invite, type Member, type Profile } from "@/lib/types";
import { initials } from "@/lib/schedule";
import { Btn, ConfirmDialog, Modal, inputCls } from "../ui";

type Props = {
  open: boolean;
  onClose: () => void;
  projectId: string;
  projectName: string;
  isOwner: boolean;
  me: Profile;
  members: Member[];
  setMembers: (m: Member[]) => void;
  toast: (t: string) => void;
};

/** Ссылка-приглашение: открывает регистрацию с уже заполненным email и ведёт в проект. */
function inviteLink(email: string, projectId: string, projectName: string) {
  const q = new URLSearchParams({
    invite: "1",
    email,
    project: projectName,
    next: `/projects/${projectId}`,
  });
  return `${window.location.origin}/login?${q.toString()}`;
}

async function copy(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

const CopyIcon = () => (
  <svg
    width="15"
    height="15"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden
  >
    <rect x="9" y="9" width="12" height="12" rx="2" />
    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
  </svg>
);

export default function MembersModal({
  open,
  onClose,
  projectId,
  projectName,
  isOwner,
  me,
  members,
  setMembers,
  toast,
}: Props) {
  const { t, rich } = useI18n();
  const supabase = useMemo(() => createClient(), []);
  const [invites, setInvites] = useState<Invite[]>([]);
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [last, setLast] = useState<{
    email: string;
    link: string;
    added: boolean;
  } | null>(null);
  const [copied, setCopied] = useState(false);
  const [removeId, setRemoveId] = useState<string | null>(null);
  const [role, setRole] = useState<"editor" | "viewer">("editor");

  async function reload() {
    const [{ data: m }, { data: inv }] = await Promise.all([
      supabase
        .from("project_members")
        .select(
          "user_id, role, profile:profiles(id,email,full_name,avatar_url)",
        )
        .eq("project_id", projectId),
      supabase
        .from("project_invites")
        .select("id,email,created_at,role")
        .eq("project_id", projectId)
        .order("created_at"),
    ]);
    if (m) setMembers(m as unknown as Member[]);
    setInvites((inv ?? []) as Invite[]);
  }

  useEffect(() => {
    if (open) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      reload();
    } else {
      setLast(null);
      setError(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  async function invite() {
    const v = email.trim().toLowerCase();
    if (!v) return;
    setBusy(true);
    setError(null);
    const { data, error } = await supabase.rpc("invite_to_project", {
      p_project: projectId,
      p_email: v,
      p_role: role,
    });
    setBusy(false);
    if (error) return setError(error.message);
    setEmail("");
    setCopied(false);
    setLast({
      email: v,
      link: inviteLink(v, projectId, projectName),
      added: data === "added",
    });
    reload();
  }

  async function copyLast() {
    if (!last) return;
    if (await copy(last.link)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  }

  async function copyFor(addr: string) {
    if (await copy(inviteLink(addr, projectId, projectName)))
      toast(t("Ссылка скопирована"));
  }

  async function changeRole(uid: string, next: "editor" | "viewer") {
    const { error } = await supabase.rpc("set_member_role", {
      p_project: projectId,
      p_user: uid,
      p_role: next,
    });
    if (error) return setError(error.message);
    toast(next === "viewer" ? t("Теперь только просмотр") : t("Теперь редактор"));
    reload();
  }

  async function removeMember(uid: string) {
    const { error } = await supabase
      .from("project_members")
      .delete()
      .eq("project_id", projectId)
      .eq("user_id", uid);
    if (error) return setError(error.message);
    reload();
  }

  async function cancelInvite(id: string) {
    const { error } = await supabase
      .from("project_invites")
      .delete()
      .eq("id", id);
    if (error) return setError(error.message);
    if (last && invites.find((i) => i.id === id)?.email === last.email)
      setLast(null);
    reload();
  }

  const smallBtn =
    "grid h-8 w-8 shrink-0 place-items-center rounded-[8px] text-[#9a988f] transition hover:bg-[#f0efe9] hover:text-ink";
  const removing = members.find((m) => m.user_id === removeId);

  return (
    <Modal open={open} onClose={onClose} title={t("Участники проекта")} width={560}>
      <div className="max-h-[45vh] overflow-auto">
        {members.map((m) => {
          const name = m.profile?.full_name || m.profile?.email || "—";
          return (
            <div
              key={m.user_id}
              className="flex items-center gap-3 border-b border-[#efede6] py-2.5"
            >
              <div className="grid h-[34px] w-[34px] place-items-center rounded-[10px] bg-ink text-[11px] font-black text-white">
                {initials(name)}
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate font-bold">
                  {name}{" "}
                  {m.user_id === me.id && (
                    <span className="font-normal text-muted">{t("(вы)")}</span>
                  )}
                </div>
                <div className="truncate text-xs text-muted">
                  {m.profile?.email}
                </div>
              </div>
              {isOwner && m.role !== "owner" ? (
                <select
                  value={m.role}
                  onChange={(e) =>
                    changeRole(m.user_id, e.target.value as "editor" | "viewer")
                  }
                  title={t("Роль в проекте")}
                  className="rounded-full border-0 bg-[#efeee8] px-2 py-0.5 text-[11px] font-extrabold text-[#5d5b54] outline-none"
                >
                  <option value="editor">{t(ROLE_LABEL.editor)}</option>
                  <option value="viewer">{t(ROLE_LABEL.viewer)}</option>
                </select>
              ) : (
                <span
                  className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold ${
                    m.role === "viewer"
                      ? "bg-[#e6effc] text-[#1d4f9a]"
                      : "bg-[#efeee8] text-[#5d5b54]"
                  }`}
                >
                  {ROLE_LABEL[m.role] ? t(ROLE_LABEL[m.role]) : m.role}
                </span>
              )}
              {isOwner && m.role !== "owner" && (
                <button
                  onClick={() => setRemoveId(m.user_id)}
                  className={smallBtn + " hover:text-bad"}
                  title={t("Убрать из проекта")}
                >
                  ×
                </button>
              )}
            </div>
          );
        })}
        {invites.map((i) => (
          <div
            key={i.id}
            className="flex items-center gap-3 border-b border-[#efede6] py-2.5"
          >
            <div className="grid h-[34px] w-[34px] place-items-center rounded-[10px] border border-dashed border-[#bdbbb2] text-xs text-muted">
              ?
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate font-bold">{i.email}</div>
              <div className="text-xs text-muted">
                {t("ждёт регистрации")} ·{" "}
                {t(i.role === "viewer" ? ROLE_LABEL.viewer : ROLE_LABEL.editor)}
              </div>
            </div>
            {isOwner && (
              <>
                <button
                  onClick={() => copyFor(i.email)}
                  className={smallBtn}
                  title={t("Скопировать ссылку-приглашение")}
                >
                  <CopyIcon />
                </button>
                <button
                  onClick={() => cancelInvite(i.id)}
                  className={smallBtn + " hover:text-bad"}
                  title={t("Отменить приглашение")}
                >
                  ×
                </button>
              </>
            )}
          </div>
        ))}
      </div>

      {isOwner ? (
        <>
          <div className="mt-4 flex gap-1 rounded-[11px] bg-[#f0efe9] p-1 text-sm font-bold">
            {(
              [
                ["editor", "Редактор", "может всё менять"],
                ["viewer", "Клиент / партнёр", "только просмотр"],
              ] as const
            ).map(([v, label, hint]) => (
              <button
                key={v}
                type="button"
                onClick={() => setRole(v)}
                className={`flex-1 rounded-[8px] px-3 py-1.5 text-left transition ${
                  role === v ? "bg-white shadow-sm" : "text-muted hover:text-ink"
                }`}
              >
                {t(label)}
                <span className="block text-[11px] font-normal text-muted">
                  {t(hint)}
                </span>
              </button>
            ))}
          </div>
          <div className="mt-2 flex gap-2">
            <input
              type="email"
              className={inputCls}
              placeholder={role === "viewer" ? t("email клиента или партнёра") : t("email коллеги")}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && invite()}
            />
            <Btn
              variant="primary"
              onClick={invite}
              disabled={busy || !email.trim()}
            >
              {t("Пригласить")}
            </Btn>
          </div>

          {last ? (
            <div className="mt-3 rounded-xl border border-[#cfe6db] bg-[#eef7f2] p-3">
              <div className="text-sm text-[#0b5a40]">
                {last.added ? (
                  <>
                    {rich(
                      "{email} уже есть в системе и добавлен в проект. Отправьте ссылку, чтобы открыть проект:",
                      { email: <b>{last.email}</b> },
                    )}
                  </>
                ) : (
                  <>
                    {rich(
                      "Отправьте {email} эту ссылку (в Telegram, WhatsApp, почтой). По ней откроется регистрация с уже заполненным email, а после входа — этот проект.",
                      { email: <b>{last.email}</b> },
                    )}
                  </>
                )}
              </div>
              <div className="mt-2 flex gap-2">
                <input
                  readOnly
                  value={last.link}
                  onFocus={(e) => e.currentTarget.select()}
                  className="min-w-0 flex-1 rounded-[9px] border border-[#cfe6db] bg-white px-2.5 py-2 text-xs text-[#35342f] outline-none"
                />
                <Btn
                  onClick={copyLast}
                  className={copied ? "border-ok text-ok" : ""}
                >
                  {copied ? (
                    t("✓ Скопировано")
                  ) : (
                    <>
                      <CopyIcon />{" "}{t("Скопировать")}
                    </>
                  )}
                </Btn>
              </div>
            </div>
          ) : (
            <p className="mt-2 text-[11px] text-muted">
              {t("После приглашения появится ссылка — отправьте её человеку. Скопировать её снова можно иконкой рядом с приглашением.")}
            </p>
          )}
        </>
      ) : (
        <p className="mt-4 text-[11px] text-muted">
          {t("Приглашать участников может только владелец проекта.")}
        </p>
      )}
      {error && <p className="mt-2 text-sm text-bad">{error}</p>}
      <div className="mt-5 flex justify-end">
        <Btn onClick={onClose}>{t("Готово")}</Btn>
      </div>

      <ConfirmDialog
        open={!!removeId}
        title={t("Убрать участника?")}
        confirmText={t("Убрать")}
        onClose={() => setRemoveId(null)}
        onConfirm={() => removeId && removeMember(removeId)}
      >
        {rich(
          "{name} потеряет доступ к проекту «{project}». Задачи и комментарии останутся.",
          {
            name: <b>{removing?.profile?.full_name || removing?.profile?.email}</b>,
            project: projectName,
          },
        )}
      </ConfirmDialog>
    </Modal>
  );
}
