import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { Brand } from "@/components/ui";
import UserMenu from "@/components/UserMenu";
import CreateProject from "@/components/CreateProject";
import ProjectCard from "@/components/ProjectCard";
import RefreshOnFocus from "@/components/RefreshOnFocus";
import { getI18n } from "@/i18n/server";
import { mailConfigured } from "@/lib/notify/mailer";

export default async function Home() {
  const supabase = await createClient();
  const { t } = await getI18n();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) redirect("/login?expired=1");

  const [{ data: profile }, { data: projects }, unreadRes, rolesRes] = await Promise.all([
    supabase
      .from("profiles")
      .select("full_name,email")
      .eq("id", auth.user.id)
      .single(),
    supabase
      .from("projects")
      .select(
        "id,name,start_date,owner_id,created_at,phases(count),tasks(count),project_members(count)",
      )
      .order("created_at", { ascending: false }),
    // непрочитанные комментарии по проектам (миграция 0009; без неё — просто пусто)
    supabase.rpc("my_unread_projects"),
    supabase
      .from("project_members")
      .select("project_id,role")
      .eq("user_id", auth.user.id),
  ]);
  const roles = new Map(
    ((rolesRes.data ?? []) as { project_id: string; role: string }[]).map(
      (r) => [r.project_id, r.role],
    ),
  );
  const unread = new Map<string, number>(
    ((unreadRes.data ?? []) as { project_id: string; unread: number }[]).map(
      (r) => [r.project_id, r.unread],
    ),
  );

  const count = (x: unknown) =>
    Array.isArray(x) && x[0] ? (x[0] as { count: number }).count : 0;

  return (
    <div className="min-h-screen">
      <RefreshOnFocus />
      <header className="sticky top-0 z-10 border-b border-line bg-bg/90 px-4 py-4 backdrop-blur md:px-6">
        <div className="mx-auto flex max-w-6xl items-center gap-4">
          <Brand />
          <div className="flex-1" />
          <UserMenu
            name={profile?.full_name ?? null}
            email={profile?.email ?? auth.user.email ?? ""}
            emailEnabled={mailConfigured()}
          />
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8 md:px-6">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight">{t("Проекты")}</h1>
            <p className="text-muted">
              {t("Ваши проекты и проекты, куда вас пригласили")}
            </p>
          </div>
          <CreateProject />
        </div>

        {!projects?.length ? (
          <div className="rounded-[17px] border border-dashed border-[#bdbbb2] p-12 text-center text-muted">
            {t("Пока нет проектов. Создайте первый — и добавьте в него фазы и задачи.")}
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {projects.map((p) => (
              <ProjectCard
                key={p.id}
                p={{
                  id: p.id,
                  name: p.name,
                  startDate: p.start_date,
                  phases: count(p.phases),
                  tasks: count(p.tasks),
                  members: count(p.project_members),
                  isOwner: p.owner_id === auth.user!.id,
                  unread: unread.get(p.id) ?? 0,
                  viewer: roles.get(p.id) === "viewer",
                }}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
