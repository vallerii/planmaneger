import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

// /api/cron — плановая рассылка писем, защищена CRON_SECRET
const PUBLIC_PATHS = ["/login", "/auth", "/t/", "/api/cron/"];

export async function updateSession(request: NextRequest) {
  let response = NextResponse.next({ request });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value),
          );
          response = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            response.cookies.set(name, value, options),
          );
        },
      },
    },
  );

  // Не вставлять код между createServerClient и getClaims()
  const { data } = await supabase.auth.getClaims();
  const user = data?.claims;
  const path = request.nextUrl.pathname;
  const isPublic = PUBLIC_PATHS.some((p) => path.startsWith(p));

  if (!user && !isPublic) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("next", path);
    return NextResponse.redirect(url);
  }
  // Страница увидела, что сессия недействительна (getUser не прошёл), а токен
  // в cookie ещё выглядит живым. Чистим cookie и показываем вход — иначе
  // «/» → «/login» → «/» зацикливается (ERR_TOO_MANY_REDIRECTS).
  if (path === "/login" && request.nextUrl.searchParams.has("expired")) {
    if (user) await supabase.auth.signOut({ scope: "local" });
    return response;
  }
  if (user && path === "/login") {
    const next = request.nextUrl.searchParams.get("next") || "/";
    const url = request.nextUrl.clone();
    url.pathname = next.startsWith("/") && !next.startsWith("//") ? next : "/";
    url.search = "";
    return NextResponse.redirect(url);
  }
  return response;
}
